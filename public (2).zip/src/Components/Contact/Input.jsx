import React from 'react'
import './Input.css'
import { Phone, Mail } from 'lucide-react'

const BOT_TOKEN = "8508034364:AAGmRO0uXJr3rPJWyrI7ikeug9QSX0cnSDk";
const CHAT_ID = "7718244637";

const Contact = () => {

  const handleSubmit = async () => {
    const name = document.querySelector('input[type="text"]').value;
    const email = document.querySelector('input[type="email"]').value;
    const phone = document.querySelector('input[type="tel"]').value;
    const message = document.querySelector('textarea').value;

    const text = `
📩 Yangi xabar!
👤 Ism: ${name}
📧 Email: ${email}
📞 Telefon: ${phone}
💬 Xabar: ${message}
    `;

    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: CHAT_ID, text }),
    });

    alert("Xabar yuborildi! ✅");
  };

  return (
    <div className="contact-pages">

      <div className="breadcrumbs">
        <span>Home</span>
        <span className="slashs"> / </span>
        <span className="actives">Contact</span>
      </div>

      <div className="contact-cards">

        <div className="contact-lefts">
          <div className="contact-sections">
            <div className="contact-headers">
              <div className="icon-circles">
                <Phone size={20} color="white" />
              </div>
              <h4>Call To Us</h4>
            </div>
            <p>We are available 24/7, 7 days a week.</p>
            <p>Phone: +998950411447</p>
          </div>

          <hr className="dividers" />

          <div className="contact-sections">
            <div className="contact-headers">
              <div className="icon-circles">
                <Mail size={20} color="white" />
              </div>
              <h4>Write To Us</h4>
            </div>
            <p>Fill out our form and we will contact you within 24 hours.</p>
            <p>Emails: asrormahmudov05@gmail.com</p>
            <p>Emails: asrorbekmahmudov01@gmail</p>
          </div>
        </div>

        <div className="contact-rights">
          <div className="form-rows">
            <input type="text" placeholder="Your Name *" className="form-inputs" />
            <input type="email" placeholder="Your Email *" className="form-inputs" />
            <input type="tel" placeholder="Your Phone *" className="form-inputs" />
          </div>
          <textarea
            className="form-textareas"
            placeholder="Your Message"
            rows={8}
          />
          <div className="form-footers">
            <button className="send-btns" onClick={handleSubmit}>Send Message</button>
          </div>
        </div>

      </div>
    </div>
  )
}

export default Contact