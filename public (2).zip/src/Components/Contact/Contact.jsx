import React from 'react'
import Navbar from "../SignUp/Navbar"
import Nav from "../SignUp/Header"
import Footer from '../Home/Footer'
import Input from './Input'
const Contact = () => {
  return (
    <div>
        <Navbar/>
        <Nav/>
        <Input/>
        <Footer/>
    </div>
  )
}

export default Contact