import React from 'react';
import { useNavigate } from 'react-router-dom';

const SignUp = () => {
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate('/home');
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <button type="submit">Create Account</button>
      </form>
    </div>
  );
};

export default SignUp;