import React, { useState } from 'react';
import { Search, Heart, ShoppingCart, Menu, X } from 'lucide-react';
import "./Header.css";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="header-container">
      <div className="header-content">
        <div className="logo">
          <h1>Exclusive</h1>
        </div>

        <nav className={`nav-menu ${isOpen ? "active" : ""}`}>
          <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/contact">Contact</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="/signup">Sign Up</a></li>
          </ul>
        </nav>

        <div className="header-actions">
          <div className="search-wrapper">
            <input type="text" placeholder="What are you looking for?" />
            <Search size={20} className="search-icon" />
          </div>
          
          <div className="icon-group">
            <Heart size={26} />
            <ShoppingCart size={26} />
            <div className="mobile-toggle" onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;