import React from 'react'
import "./Navbar.css"
import { Menu } from 'lucide-react';
const Navbar = () => {
  return (
   <div className='sign'>
    <i>Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%!</i>    
     <u> ShopNow </u>
    
   </div>
  )
}

export default Navbar