import React from 'react'
import "./Story.css"
import a3 from "../../assets/a3.png"

const Story = () => {
  return (
    <div className='stories-container'>
      <div className='stories-content'>
          <h1>Our Story</h1>
          <p>
            Launched in 2015, Exclusive is South Asia’s premier online shopping 
            marketplace with an active presence in Bangladesh. Supported 
            by wide range of tailored marketing, data and service solutions, 
            Exclusive has 10,500 sellers and 300 brands and serves 3 
            millions customers across the region.
          </p>
          <p>
            Exclusive has more than 1 Million products to offer, growing at a 
            very fast. Exclusive offers a diverse assortment in categories 
            ranging from consumer.
          </p>
      </div>
      
      <div className='stories-img'>
          <img src={a3} alt="Our Story" />
      </div>
    </div>
  )
}

export default Story