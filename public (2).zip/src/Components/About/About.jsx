import React from 'react'
import Navbar from '../SignUp/Navbar'
import Nav from "../SignUp/Header"
import Footer from '../Home/Footer'
import Story from './Story'
import Hover from './Hover'
import Human from './Human'
import Last from './Last'
const About = () => {
  return (
    <div>
        <Navbar/>
        <Nav/>
        <Story/>
        <Hover/>
        <Human/>
        <Last/>
        <Footer/>
    </div>
  )
}

export default About