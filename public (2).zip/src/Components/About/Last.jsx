import React, { useEffect } from 'react'
import "./Last.css"
import { Truck, Headphones, ShieldCheck } from 'lucide-react'
import AOS from 'aos'
import 'aos/dist/aos.css'


const Last = () => {
      useEffect(() => {
        AOS.init()

      }, [])
  return (
<div className='last'>
    <div className='last1' data-aos="fade-right" data-aos-duration="600">
        <div className='icon-circle'>
            <Truck size={40}/>
        </div>
        <h5>FREE AND FAST DELIVERY</h5>
        <p>Free delivery for all orders over $140</p>
    </div>

    <div className='last2' data-aos="fade-up" data-aos-duration="900">
        <div className='icon-circle'>
            <Headphones size={40}/>
        </div>
        <h5>24/7 CUSTOMER SERVICE</h5>
        <p>Friendly 24/7 customer support</p>
    </div>

    <div className='last3' data-aos="fade-left" data-aos-duration="1200">
        <div className='icon-circle'>
            <ShieldCheck size={40}/>
        </div>
        <h5>MONEY BACK GUARANTEE</h5>
        <p>We return money within 30 days</p>
    </div>
</div>
  )
}

export default Last