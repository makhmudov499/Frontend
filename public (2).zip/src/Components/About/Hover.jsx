import React, { useEffect } from 'react'
import "./Hover.css"
import { Store, CircleDollarSign, Briefcase, Coins } from 'lucide-react'
import AOS from 'aos'
import 'aos/dist/aos.css'
import CountUp from 'react-countup'
import a9 from "../../assets/a9.png"
import a10 from "../../assets/a10.png"
import a11 from "../../assets/a11.png"
import a12 from "../../assets/a12.png"

const products = [
{
   id: 1,
    name: "HAVIT HV-G92 Gamepad",
    price: 120,
    oldPrice: 160,
    discount: "-40%",
    rating: 5,
    reviews: 88,
    img: a9
},
{
    id: 2,
    name: "AK-900 Wired Keyboard",
    price: 960,
    oldPrice: 1160,
    discount: "-35%",
    rating: 4,
    reviews: 75,
    img: a10
  },
]





const Hover = () => {
  useEffect(() => {
    AOS.init()
  }, [])

  return (
    <>
      <div className='xax1'>
       <div className='ha1' data-aos="fade-right">
  <Store width={40} height={40}/>
  <h1><CountUp end={10500} duration={2} /></h1>
  <p>Sallers active our site</p>
</div>

<div className='ha2' data-aos="fade-up" data-aos-delay="100">
  <CircleDollarSign width={40} height={40}/>
  <h1><CountUp end={33000} duration={2} /></h1>
  <p>Mopnthly Produduct Sale</p>
</div>

<div className='ha3' data-aos="fade-down" data-aos-delay="200">
  <Briefcase width={40} height={40}/>
  <h1><CountUp end={45500} duration={2} /></h1>
  <p>Customer active in our site</p>
</div>

<div className='ha4' data-aos="fade-left" data-aos-delay="300">
  <Coins width={40} height={40}/>
  <h1><CountUp end={25000} duration={2} /></h1>
  <p>Anual gross sale in our site</p>
</div>

      </div>

    </>
  )
}

export default Hover