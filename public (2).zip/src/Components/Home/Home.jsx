import React from 'react'
import { Links } from 'react-router-dom'
import Nav from "../SignUp/Header"
import Navbar from "../SignUp/Navbar"
import Footer from './Footer'
import SwiperComp from './Swiper'
import Map from './Map'
const Home = () => {
  return (
    <div className='wrapper'>
        <Navbar/>
        <Nav/>
        <SwiperComp/>
        <Map/>
        <Footer/>
    </div>
  )
}

export default Home