import React from 'react'
import "./Map.css"
import CountUp from 'react-countup'
import { Heart, Eye, Star, ChevronLeft, ChevronRight } from 'lucide-react'
import { Swiper, SwiperSlide } from 'swiper/react'
import { Navigation } from 'swiper/modules'
import 'swiper/css'
import 'swiper/css/navigation'
import a9 from "../../assets/a9.png"
import a10 from "../../assets/a10.png"
import a11 from "../../assets/a11.png"
import a12 from "../../assets/a12.png"

const products = [
{ id: 1, name: "HAVIT HV-G92 Gamepad", price: 120, oldPrice: 160, discount: "-40%", rating: 5, reviews: 88, img: a9 },
{ id: 2, name: "AK-900 Wired Keyboard", price: 960, oldPrice: 1160, discount: "-35%", rating: 4, reviews: 75, img: a10 },
{ id: 3, name: "IPS LCD Gaming Monitor", price: 370, oldPrice: 400, discount: "-30%", rating: 5, reviews: 99, img: a11 },
{ id: 4, name: "S-Series Comfort Chair", price: 375, oldPrice: 400, discount: "-25%", rating: 5, reviews: 99, img: a12 },
{ id: 5, name: "HAVIT HV-G92 Gamepad", price: 120, oldPrice: 160, discount: "-40%", rating: 5, reviews: 88, img: a9 },
{ id: 6, name: "AK-900 Wired Keyboard", price: 960, oldPrice: 1160, discount: "-35%", rating: 4, reviews: 75, img: a10 },
{ id: 7, name: "IPS LCD Gaming Monitor", price: 370, oldPrice: 400, discount: "-30%", rating: 5, reviews: 99, img: a11 },
{ id: 8, name: "S-Series Comfort Chair", price: 375, oldPrice: 400, discount: "-25%", rating: 5, reviews: 99, img: a12 },
]




const FlashSales = () => {
  return (
    <div className='map'>
      <div className="map-top">
        <div className="map-left">
          <div className="map-today">
            <span className="map-bar"></span>
            <p>Today's</p>
          </div>
          <div className="map-middle">
            <h2>Flash Sales</h2>
            <div className="timer">
              <div className="timer-item">
                <p>Days</p>
                <b><CountUp end={3} duration={5} /></b>
              </div>
              <span className="timer-colon">:</span>
              <div className="timer-item">
                <p>Hours</p>
                <b><CountUp end={23} duration={5} /></b>
              </div>
              <span className="timer-colon">:</span>
              <div className="timer-item">
                <p>Minutes</p>
                <b><CountUp end={19} duration={5} /></b>
              </div>
              <span className="timer-colon">:</span>
              <div className="timer-item">
                <p>Seconds</p>
                <b><CountUp end={56} duration={5} /></b>
              </div>
            </div>
          </div>
        </div>

        <div className="map-arrows">
          <button className="map-arrow swiper-prev-btn"><ChevronLeft size={20} /></button>
          <button className="map-arrow swiper-next-btn"><ChevronRight size={20} /></button>
        </div>
      </div>

      <Swiper
        modules={[Navigation]}
        navigation={{
          prevEl: '.swiper-prev-btn',
          nextEl: '.swiper-next-btn',
        }}
        slidesPerView={4}
        spaceBetween={20}
        className="map-swiper"
      >
        {products.map((product) => (
          <SwiperSlide key={product.id}>
            <div className="map-card">
              <div className="map-card-img">
                <span className="map-discount">{product.discount}</span>
                <img src={product.img} alt={product.name} />
                <div className="map-icons">
                  <Heart size={20} />
                  <Eye size={20} />
                </div>
              </div>
              <h3>{product.name}</h3>
              <div className="map-price">
                <span className="map-new">${product.price}</span>
                <s className="map-old">${product.oldPrice}</s>
              </div>
              <div className="map-stars">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={15} fill={i < product.rating ? "#FFAD33" : "none"} color={i < product.rating ? "#FFAD33" : "#ccc"} />
                ))}
                <span>({product.reviews})</span>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
        <button className='btn123'>View All Products</button>
    </div>
  )
}

export default FlashSales