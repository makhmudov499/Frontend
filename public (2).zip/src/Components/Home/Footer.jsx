import React from 'react';
import { SendHorizontal, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';
import './Footer.css';

    import a2 from "../../assets/a2.png"; 

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-column">
          <h2 className="footer-logo">Exclusive</h2>
          <h3>Subscribe</h3>
          <p>Get 10% off your first order</p>
          <div className="subscribe-input">
            <input type="email" placeholder="Enter your email" />
            <SendHorizontal size={20} className="send-icon" />
          </div>
        </div>

        <div className="footer-column">
          <h3>Support</h3>
          <p>111 Bijoy sarani, Dhaka, <br /> DH 1515, Bangladesh.</p>
          <p>exclusive@gmail.com</p>
          <p>+88015-88888-9999</p>
        </div>

        <div className="footer-column">
          <h3>Account</h3>
          <ul>
            <li><a href="#">My Account</a></li>
            <li><a href="#">Login / Register</a></li>
            <li><a href="#">Cart</a></li>
            <li><a href="#">Wishlist</a></li>
            <li><a href="#">Shop</a></li>
          </ul>
        </div>

        <div className="footer-column">
          <h3>Quick Link</h3>
          <ul>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms Of Use</a></li>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </div>

        <div className="footer-column">
          <h3>Download App</h3>
          <p className="app-promo">Save $3 with App New User Only</p>
          <div className="app-download-area">
            <div className="qr-code-img">
              <img src={a2} alt="QR Code" />
            </div>
            <div className="app-stores">
              <img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" alt="Google Play" />
              <img src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg" alt="App Store" />
            </div>
          </div>
          <div className="social-icons">
            <Facebook size={24} />
            <Twitter size={24} />
            <Instagram size={24} />
            <Linkedin size={24} />
          </div>
        </div>
      </div>
      
      <div className="footer-bottom">
        <p>&copy; Copyright Rimel 2022. All right reserved</p>
      </div>
    </footer>
  );
};

export default Footer;