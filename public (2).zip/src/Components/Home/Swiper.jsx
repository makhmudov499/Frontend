import React, { useState, useEffect } from "react";
import "./Swiper.css";
import a3 from "../../assets/a3.png";
import a4 from "../../assets/a4.png";
import a5 from "../../assets/a5.png";
import a6 from "../../assets/a6.png";
import a8 from "../../assets/a8.png";

const slides = [a3, a8, a8, a8, a8];

const SwiperComp = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="sw-wrapper">
      <div className="sw-sidebar">
        <p>Woman's Fashion <span>›</span></p>
        <p>Men's Fashion <span>›</span></p>
        <p>Electronics</p>
        <p>Home & Lifestyle</p>
        <p>Medicine</p>
        <p>Sports & Outdoor</p>
        <p>Baby's & Toys</p>
        <p>Groceries & Pets</p>
        <p>Health & Beauty</p>
      </div>

      <div className="sw-slider">
        <img src={slides[current]} alt="slide" className="sw-image" />
        <div className="sw-dots">
          {slides.map((_, i) => (
            <span
              key={i}
              className={`sw-dot ${i === current ? "active" : ""}`}
              onClick={() => setCurrent(i)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default SwiperComp;