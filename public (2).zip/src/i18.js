import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
import eng from './locales/ENG.json'
import rus from './locales/RUS.json'
import uzb from './locales/UZB.json'

i18n.use(initReactI18next).init({
  resources: {
    eng: { translation: eng },
    rus: { translation: rus },
    uzb: { translation: uzb },
  },
  lng: 'eng',
  fallbackLng: 'eng',
})

export default i18n