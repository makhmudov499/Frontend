import React from 'react'
import "./Map.css"
import CountUp from 'react-countup'

const Map = () => {
    
  return (
    <div className='map'>

      <div className="map-top">
        <div className="map-left">
          <div className="map-today">
            <span className="map-bar"></span>
            <p>Today's</p>
          </div>
          <div className="map-middle">
            <h2>Flash Sales</h2>
            <div className="timer">
              <div className="timer-item">
                <p>Days</p>
                <b> <CountUp end={3} duration={5} /></b>
              </div>
              <span className="timer-colon">:</span>
              <div className="timer-item">
                <p>Hours</p>
                <b> <CountUp end={23} duration={5} /></b>
              </div>
              <span className="timer-colon">:</span>
              <div className="timer-item">
                <p>Minutes</p>
                <b><CountUp end={19} duration={5} /></b>
              </div>
              <span className="timer-colon">:</span>
              <div className="timer-item">
                <p>Seconds</p>
                <b><CountUp end={56} duration={5} /></b>
              </div>
            </div>
          </div>
        </div>

        <div className="map-arrows">
          <button className="map-arrow">←</button>
          <button className="map-arrow">→</button>
        </div>
      </div>


    </div>
  )
}

export default Map